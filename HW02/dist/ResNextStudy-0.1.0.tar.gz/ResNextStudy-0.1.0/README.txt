This is homework ResNext realization based on ResNet from pytorch.
