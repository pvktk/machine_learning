from distutils.core import setup

setup(
    name='ResNextStudy',
    version='0.1.0',
    author='Student Studentson',
    packages=['resnext'],
    description='Homework ResNext based on ResNet.',
    long_description=open('README.txt').read(),
)
